import android.view.View
import androidx.viewpager2.widget.ViewPager2

class FlipPageTransformer : ViewPager2.PageTransformer {
    override fun transformPage(page: View, position: Float) {
        page.apply {
            val pageWidth = width
            val pageHeight = height
            
            when {
                position < -1 -> { // [-Infinity,-1)
                    // Page is way off-screen to the left
                    alpha = 0f
                }
                position <= 0 -> { // [-1,0]
                    // Page is moving out to the left
                    alpha = 1 + position
                    translationX = pageWidth * -position
                    
                    // 3D rotation
                    rotationY = 15 * -position
                    pivotX = 0f
                    pivotY = pageHeight / 2f
                    
                    // Scale effect
                    val scaleFactor = 0.85f + (1 - 0.85f) * (1 - Math.abs(position))
                    scaleX = scaleFactor
                    scaleY = scaleFactor
                }
                position <= 1 -> { // (0,1]
                    // Page is moving in from the right
                    alpha = 1 - position
                    translationX = pageWidth * -position
                    
                    // 3D rotation for next page
                    rotationY = 15 * -position
                    pivotX = pageWidth.toFloat()
                    pivotY = pageHeight / 2f
                    
                    // Scale effect
                    val scaleFactor = 0.85f + (1 - 0.85f) * (1 - Math.abs(position))
                    scaleX = scaleFactor
                    scaleY = scaleFactor
                }
                else -> { // (1,+Infinity]
                    // Page is way off-screen to the right
                    alpha = 0f
                }
            }
        }
    }
}
